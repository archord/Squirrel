/* Version number of package */
#define VERSION "6.2.0"
/* Define to the version of this package. */
#define PACKAGE_VERSION "6.2.0"
